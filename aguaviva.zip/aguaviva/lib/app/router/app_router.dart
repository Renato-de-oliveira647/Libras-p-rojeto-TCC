import 'package:go_router/go_router.dart';

import '../../features/dictionary/presentation/pages/dictionary_page.dart';
import '../../features/home/presentation/pages/home_page.dart';
import '../../features/translation/presentation/pages/sign_to_text_page.dart';
import '../../features/translation/presentation/pages/text_to_sign_page.dart';
import '../navigation/app_shell_page.dart';
import 'app_routes.dart';

abstract final class AppRouter {
  static final GoRouter router = GoRouter(
    initialLocation: AppRoutePaths.home,
    routes: [
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) {
          return AppShellPage(navigationShell: navigationShell);
        },
        branches: [
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: AppRoutePaths.home,
                name: AppRouteNames.home,
                builder: (context, state) => const HomePage(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: AppRoutePaths.textToSign,
                name: AppRouteNames.textToSign,
                builder: (context, state) => const TextToSignPage(),
                routes: [
                  GoRoute(
                    path: AppRoutePaths.signToText,
                    name: AppRouteNames.signToText,
                    builder: (context, state) => const SignToTextPage(),
                  ),
                ],
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: AppRoutePaths.dictionary,
                name: AppRouteNames.dictionary,
                builder: (context, state) => const DictionaryPage(),
              ),
            ],
          ),
        ],
      ),
    ],
  );
}
