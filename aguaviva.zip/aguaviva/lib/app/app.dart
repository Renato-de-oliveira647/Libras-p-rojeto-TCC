import 'package:flutter/material.dart';

import 'router/app_router.dart';

class SinalizaApp extends StatelessWidget {
  const SinalizaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Sinaliza',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B8B6E)),
        scaffoldBackgroundColor: const Color(0xFFF7FAFC),
      ),
      routerConfig: AppRouter.router,
    );
  }
}
