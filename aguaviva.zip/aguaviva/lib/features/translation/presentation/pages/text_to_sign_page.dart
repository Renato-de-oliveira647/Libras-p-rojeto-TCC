import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:speech_to_text/speech_recognition_error.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:video_player/video_player.dart';

import '../../../../app/router/app_routes.dart';
import '../../../../utils/libras/libras_export.dart';

class TextToSignPage extends StatefulWidget {
  const TextToSignPage({super.key});

  @override
  State<TextToSignPage> createState() => _TextToSignPageState();
}

class _TextToSignPageState extends State<TextToSignPage> {
  final TextEditingController _controller = TextEditingController();
  final SpeechToText _speechToText = SpeechToText();

  // Variáveis de Speech-to-Text
  bool _speechEnabled = false;
  bool _isListening = false;
  bool _isSpeechInitializing = false;
  String? _speechStatusMessage;

  // Variáveis de tradução para Libras
  List<TranslatedSign>? _translatedSigns;
  bool _isTranslating = false;
  int _currentVideoIndex = 0;
  bool _isPlayingVideo = false;
  VideoPlayerController? _videoController;
  bool _isSwitchingVideo = false;
  bool _didShowPlaybackError = false;
  String _lastRecognizedWords = '';
  bool _isPreparingVideo = false;
  bool _isCurrentAssetFound = false;
  bool _isPlayerReady = false;
  String _assetStatus = 'Aguardando tradução';
  String _playerStatus = 'Não inicializado';
  String? _currentVideoPath;
  bool _isAutoSequencePlaying = false;
  bool _isAdvancingSequence = false;

  @override
  void initState() {
    super.initState();
    _initializeSpeechToText();
  }

  @override
  void dispose() {
    _speechToText.stop();
    _disposeVideoController();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _disposeVideoController() async {
    final controller = _videoController;
    _videoController = null;
    if (controller == null) {
      return;
    }

    controller.removeListener(_onVideoControllerChanged);
    try {
      await controller.pause();
    } catch (_) {}
    try {
      await controller.dispose();
    } catch (_) {}
  }

  void _onVideoControllerChanged() {
    if (!mounted) {
      return;
    }

    final controller = _videoController;
    if (controller == null || !controller.value.isInitialized) {
      return;
    }

    final value = controller.value;
    final hasDuration = value.duration > Duration.zero;
    final reachedEnd = hasDuration && value.position >= value.duration;

    if (reachedEnd && !value.isPlaying && _isPlayingVideo) {
      if (_isAutoSequencePlaying) {
        _advanceToNextSignInSequence();
        return;
      }

      setState(() {
        _isPlayingVideo = false;
      });
    }
  }

  Future<void> _advanceToNextSignInSequence() async {
    if (_isAdvancingSequence || !mounted) {
      return;
    }

    _isAdvancingSequence = true;
    try {
      if (_translatedSigns == null || _translatedSigns!.isEmpty) {
        _isAutoSequencePlaying = false;
        if (mounted) {
          setState(() {
            _isPlayingVideo = false;
          });
        }
        return;
      }

      final nextIndex = _currentVideoIndex + 1;
      if (nextIndex >= _translatedSigns!.length) {
        _isAutoSequencePlaying = false;
        if (mounted) {
          setState(() {
            _isPlayingVideo = false;
            _playerStatus = 'Sequência finalizada';
          });
        }
        return;
      }

      if (mounted) {
        setState(() {
          _currentVideoIndex = nextIndex;
        });
      }

      await _playCurrentSignVideo(autoPlay: true);
    } finally {
      _isAdvancingSequence = false;
    }
  }

  Future<void> _initializeSpeechToText() async {
    if (_isSpeechInitializing) {
      return;
    }

    setState(() {
      _isSpeechInitializing = true;
      _speechStatusMessage = null;
    });

    final available = await _speechToText.initialize(
      onStatus: _onSpeechStatus,
      onError: _onSpeechError,
      debugLogging: false,
    );

    if (!mounted) {
      return;
    }

    setState(() {
      _speechEnabled = available;
      _isSpeechInitializing = false;
      if (!available) {
        _speechStatusMessage = 'Reconhecimento de voz indisponivel neste dispositivo.';
      }
    });
  }

  void _onSpeechStatus(String status) {
    if (!mounted) {
      return;
    }

    setState(() {
      _isListening = status == 'listening';
      if (status == 'notListening' || status == 'done') {
        _isListening = false;
      }
    });
  }

  void _onSpeechError(SpeechRecognitionError error) {
    if (!mounted) {
      return;
    }

    setState(() {
      _isListening = false;
      _speechStatusMessage = 'Erro de reconhecimento: ${error.errorMsg}';
    });
  }

  void _onSpeechResult(SpeechRecognitionResult result) {
    if (!mounted) {
      return;
    }

    final recognized = result.recognizedWords;
    if (recognized == _lastRecognizedWords) {
      return;
    }

    _lastRecognizedWords = recognized;

    setState(() {
      _controller.text = recognized;
      _controller.selection = TextSelection.collapsed(offset: _controller.text.length);
      _speechStatusMessage = null;
    });
  }

  Future<String?> _resolvePortugueseLocaleId() async {
    final locales = await _speechToText.locales();

    for (final locale in locales) {
      if (locale.localeId == 'pt_BR') {
        return locale.localeId;
      }
    }

    for (final locale in locales) {
      if (locale.localeId.startsWith('pt_')) {
        return locale.localeId;
      }
    }

    return null;
  }

  Future<void> _toggleListening() async {
    FocusScope.of(context).unfocus();

    if (_isSpeechInitializing) {
      return;
    }

    if (!_speechEnabled) {
      await _initializeSpeechToText();
      if (!_speechEnabled) {
        return;
      }
    }

    if (_speechToText.isListening) {
      await _speechToText.stop();
      if (!mounted) {
        return;
      }
      setState(() {
        _isListening = false;
      });
      return;
    }

    final localeId = await _resolvePortugueseLocaleId();
    await _speechToText.listen(
      onResult: _onSpeechResult,
      localeId: localeId,
      listenMode: ListenMode.dictation,
      partialResults: true,
      cancelOnError: true,
    );

    if (!mounted) {
      return;
    }

    setState(() {
      _isListening = true;
      _speechStatusMessage = null;
    });
  }

  /// Traduz o texto para Libras
  Future<void> _translateText() async {
    if (_controller.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor, digite algo para traduzir.')),
      );
      return;
    }

    FocusScope.of(context).unfocus();

    if (_speechToText.isListening) {
      await _speechToText.stop();
    }

    setState(() {
      _isTranslating = true;
      _translatedSigns = null;
      _currentVideoIndex = 0;
      _isPlayingVideo = false;
      _isAutoSequencePlaying = false;
      _isCurrentAssetFound = false;
      _isPlayerReady = false;
      _assetStatus = 'Aguardando tradução';
      _playerStatus = 'Não inicializado';
      _currentVideoPath = null;
    });

    await _disposeVideoController();

    // Simular processamento
    await Future.delayed(const Duration(milliseconds: 500));

    if (!mounted) return;

    // Traduzir usando o pipeline
    final signs = LibrasTranslator.translate(_controller.text);

    // Extrair apenas sinais com vídeos válidos.
    var validSigns = signs.where((s) => s.videoPaths.isNotEmpty).toList();

    // Evita sobrecarga no thread principal quando a frase gera muitos sinais.
    const maxSignsPerPlayback = 12;
    if (validSigns.length > maxSignsPerPlayback) {
      validSigns = validSigns.take(maxSignsPerPlayback).toList();
    }

    _didShowPlaybackError = false;

    setState(() {
      _translatedSigns = validSigns;
      _isTranslating = false;
      _currentVideoIndex = 0;
    });

    if (validSigns.isEmpty) {
      await _disposeVideoController();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nenhum sinal disponível para traduzir.')),
      );
      return;
    }

    // Evita carga imediata de decodificação na thread principal após tradução.
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tradução pronta. Pré-carregando primeiro vídeo...')),
      );
    }

    await _playCurrentSignVideo(autoPlay: false);
  }

  /// Reproduz a sequência de sinais com transição suave
  Future<void> _playSignSequence() async {
    if (_translatedSigns == null || _translatedSigns!.isEmpty) {
      return;
    }

    _isAutoSequencePlaying = true;
    setState(() {
      _isPlayingVideo = true;
    });
    await _playCurrentSignVideo(autoPlay: true);
  }

  Future<void> _playCurrentSignVideo({required bool autoPlay}) async {
    if (_translatedSigns == null || _translatedSigns!.isEmpty) {
      return;
    }

    if (_isPreparingVideo) {
      return;
    }

    if (_currentVideoIndex < 0 || _currentVideoIndex >= _translatedSigns!.length) {
      return;
    }

    final sign = _translatedSigns![_currentVideoIndex];
    if (sign.videoPaths.isEmpty) {
      await _playNextSign();
      return;
    }

    _isPreparingVideo = true;

    setState(() {
      _isSwitchingVideo = true;
      _isPlayingVideo = autoPlay;
      _isPlayerReady = false;
      _isCurrentAssetFound = false;
      _assetStatus = 'Verificando asset...';
      _playerStatus = 'Inicializando player...';
    });

    final candidates = List<String>.from(sign.videoPaths);
    String? lastError;

    try {
      // Evita manter dois decoders ativos ao mesmo tempo em aparelhos com pouca memoria.
      await _disposeVideoController();

      final orderedCandidates = await _orderCandidatesByAssetSize(candidates);

      for (final path in orderedCandidates) {
        try {
          if (mounted) {
            setState(() {
              _currentVideoPath = path;
              _assetStatus = 'Verificando asset: $path';
              _playerStatus = 'Inicializando player...';
            });
          }

          try {
            await rootBundle.load(path);
            if (mounted) {
              setState(() {
                _isCurrentAssetFound = true;
                _assetStatus = 'Asset encontrado';
              });
            }
          } catch (_) {
            lastError = 'Asset nao encontrado no bundle: $path';
            if (mounted) {
              setState(() {
                _isCurrentAssetFound = false;
                _assetStatus = 'Asset ausente no bundle';
              });
            }
            continue;
          }

          final controller = VideoPlayerController.asset(path);
          await controller.initialize();

          if (!controller.value.isInitialized) {
            await controller.dispose();
            lastError = 'Player não inicializou para: $path';
            continue;
          }

          if (!mounted) {
            await controller.dispose();
            _isPreparingVideo = false;
            return;
          }

          controller.addListener(_onVideoControllerChanged);
          if (autoPlay) {
            await controller.play();
          }

          setState(() {
            _videoController = controller;
            _isPlayingVideo = autoPlay;
            _isSwitchingVideo = false;
            _isPlayerReady = true;
            _playerStatus = autoPlay ? 'Player pronto (reproduzindo)' : 'Player pronto para reproduzir';
          });

          break;
        } catch (e) {
          lastError = e.toString();
        }
      }

      if (_isSwitchingVideo) {
        final switchedToSpelling = await _replaceCurrentSignWithSpellingFallback(
          sign,
          autoPlay: autoPlay,
        );
        if (switchedToSpelling) {
          _isPreparingVideo = false;
          await _playCurrentSignVideo(autoPlay: autoPlay);
          return;
        }
        throw Exception(lastError ?? 'No playable video found for current sign');
      }
    } catch (e) {
      if (!mounted) {
        _isPreparingVideo = false;
        return;
      }

      setState(() {
        _isPlayingVideo = false;
        _isSwitchingVideo = false;
        _isAutoSequencePlaying = false;
        _isPlayerReady = false;
        _playerStatus = 'Falha no player';
      });

      if (!_didShowPlaybackError) {
        _didShowPlaybackError = true;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Falha ao reproduzir video mp4: $e')),
        );
      }
    } finally {
      _isPreparingVideo = false;
    }
  }

  Future<bool> _replaceCurrentSignWithSpellingFallback(
    TranslatedSign failedSign, {
    required bool autoPlay,
  }) async {
    if (_translatedSigns == null || _translatedSigns!.isEmpty) {
      return false;
    }

    final reason = failedSign.fallbackReason ?? '';
    if (!reason.startsWith('Tentando variações 1/2/3 para')) {
      return false;
    }

    final spellingSigns = LibrasTranslator.getSpellingFallbackSigns(failedSign.word);
    if (spellingSigns.isEmpty) {
      return false;
    }

    final currentList = List<TranslatedSign>.from(_translatedSigns!);
    if (_currentVideoIndex < 0 || _currentVideoIndex >= currentList.length) {
      return false;
    }

    currentList.removeAt(_currentVideoIndex);
    currentList.insertAll(_currentVideoIndex, spellingSigns);

    if (!mounted) {
      return false;
    }

    setState(() {
      _translatedSigns = currentList;
      _isSwitchingVideo = false;
      _isPlayingVideo = autoPlay;
      _isPlayerReady = false;
      _assetStatus = 'Palavra sem vídeo, iniciando soletração';
      _playerStatus = 'Fallback para soletração';
    });
    return true;
  }

  Future<List<String>> _orderCandidatesByAssetSize(List<String> candidates) async {
    final sizedCandidates = <MapEntry<String, int>>[];

    for (final path in candidates) {
      try {
        final data = await rootBundle.load(path);
        sizedCandidates.add(MapEntry(path, data.lengthInBytes));
      } catch (_) {
        // Ignora aqui; o fluxo principal ja trata asset ausente com status detalhado.
      }
    }

    if (sizedCandidates.isEmpty) {
      return candidates;
    }

    sizedCandidates.sort((a, b) => a.value.compareTo(b.value));
    return sizedCandidates.map((e) => e.key).toList();
  }

  Future<void> _playPreviousSign() async {
    if (!mounted || _translatedSigns == null || _translatedSigns!.isEmpty) {
      return;
    }

    final previousIndex = _currentVideoIndex - 1;
    if (previousIndex < 0) {
      return;
    }

    setState(() {
      _currentVideoIndex = previousIndex;
      _isPlayingVideo = false;
    });

    _isAutoSequencePlaying = false;

    await _playCurrentSignVideo(autoPlay: true);
  }

  Future<void> _playNextSign() async {
    if (!mounted || _translatedSigns == null || _translatedSigns!.isEmpty) {
      return;
    }

    final nextIndex = _currentVideoIndex + 1;
    if (nextIndex >= _translatedSigns!.length) {
      return;
    }

    setState(() {
      _currentVideoIndex = nextIndex;
      _isPlayingVideo = false;
    });

    _isAutoSequencePlaying = false;

    await _playCurrentSignVideo(autoPlay: true);
  }

  /// Obtém a descrição do sinal atual
  String? _getCurrentSignDescription() {
    if (_translatedSigns == null || _currentVideoIndex >= _translatedSigns!.length) {
      return null;
    }
    
    final sign = _translatedSigns![_currentVideoIndex];
    if (sign.fallbackReason != null) {
      return '${sign.word} (${sign.fallbackReason})';
    }
    return sign.word;
  }

  TranslatedSign? _getCurrentSign() {
    if (_translatedSigns == null || _translatedSigns!.isEmpty) {
      return null;
    }
    if (_currentVideoIndex < 0 || _currentVideoIndex >= _translatedSigns!.length) {
      return null;
    }
    return _translatedSigns![_currentVideoIndex];
  }

  String? _extractSpelledWord(String? fallbackReason) {
    if (fallbackReason == null) {
      return null;
    }
    final match = RegExp(r'^Soletrando "(.+)"$').firstMatch(fallbackReason);
    return match?.group(1);
  }

  ({String word, List<String> letters, int currentLetterIndex})? _getSpellingProgress() {
    final sign = _getCurrentSign();
    if (sign == null) {
      return null;
    }

    final spelledWord = _extractSpelledWord(sign.fallbackReason);
    if (spelledWord == null || _translatedSigns == null) {
      return null;
    }

    final reason = sign.fallbackReason;
    int start = _currentVideoIndex;
    int end = _currentVideoIndex;

    while (start > 0 && _translatedSigns![start - 1].fallbackReason == reason) {
      start--;
    }

    while (end < _translatedSigns!.length - 1 && _translatedSigns![end + 1].fallbackReason == reason) {
      end++;
    }

    final letters = <String>[];
    for (int i = start; i <= end; i++) {
      letters.add(_translatedSigns![i].word);
    }

    return (
      word: spelledWord,
      letters: letters,
      currentLetterIndex: _currentVideoIndex - start,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Texto para Libras'),
        elevation: 0,
        actions: [
          TextButton(
            onPressed: () => context.pushNamed(AppRouteNames.signToText),
            child: const Text('Libras para Texto'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFFE5E7EB)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      'Texto em Português',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: _toggleListening,
                      icon: Icon(
                        _isListening ? Icons.mic_rounded : Icons.mic_none_rounded,
                      ),
                      style: IconButton.styleFrom(
                        backgroundColor: _isListening
                            ? const Color(0xFFEF4444)
                            : const Color(0xFFE5E7EB),
                        foregroundColor: _isListening
                            ? Colors.white
                            : const Color(0xFF4B5563),
                      ),
                      tooltip: _isListening ? 'Parar microfone' : 'Ativar microfone',
                    ),
                  ],
                ),
                if (_speechStatusMessage != null) ...[
                  const SizedBox(height: 6),
                  Text(
                    _speechStatusMessage!,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: const Color(0xFFDC2626),
                    ),
                  ),
                ],
                const SizedBox(height: 8),
                TextField(
                  controller: _controller,
                  minLines: 4,
                  maxLines: 5,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    hintText: 'Digite o texto para traduzir...',
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.all(14),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(color: Color(0xFFD1D5DB)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(color: Color(0xFFD1D5DB)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(color: Color(0xFF2563EB), width: 1.5),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Text(
                      '${_controller.text.length} caracteres',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: const Color(0xFF6B7280),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Spacer(),
                    SizedBox(
                      height: 42,
                      child: FilledButton(
                        onPressed: _isTranslating ? null : _translateText,
                        style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF2F80ED),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                        ),
                        child: Text(
                          _isTranslating ? 'Traduzindo...' : 'Traduzir',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),
          Text(
            'Tradução em Libras',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.grey.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5E7EB)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Visualização do sinal atual
                Container(
                  width: double.infinity,
                  height: 210,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.black,
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 220),
                    child: _videoController != null
                        && _videoController!.value.isInitialized
                        ? Stack(
                            key: ValueKey(_currentVideoIndex),
                            fit: StackFit.expand,
                            children: [
                                FittedBox(
                                  fit: BoxFit.cover,
                                  child: SizedBox(
                                    width: _videoController!.value.size.width > 0
                                        ? _videoController!.value.size.width
                                        : 16,
                                    height: _videoController!.value.size.height > 0
                                        ? _videoController!.value.size.height
                                        : 9,
                                    child: VideoPlayer(_videoController!),
                                  ),
                              ),
                              Positioned(
                                right: 8,
                                top: 8,
                                child: DecoratedBox(
                                  decoration: BoxDecoration(
                                    color: Colors.black.withValues(alpha: 0.45),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    child: Text(
                                      '${_currentVideoIndex + 1}/${_translatedSigns?.length ?? 0}',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )
                        : Center(
                            key: const ValueKey('placeholder'),
                            child: _isSwitchingVideo
                                ? const CircularProgressIndicator(color: Colors.white)
                                : Icon(
                                    Icons.sign_language_outlined,
                                    size: 52,
                                    color: Colors.white.withValues(alpha: 0.7),
                                  ),
                          ),
                  ),
                ),
                const SizedBox(height: 12),
                // Descrição do sinal atual
                Text(
                  _translatedSigns != null && _translatedSigns!.isNotEmpty
                      ? 'Sinal: ${_getCurrentSignDescription() ?? "Desconhecido"}'
                      : 'Animação dos sinais',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: _translatedSigns != null && _translatedSigns!.isNotEmpty
                        ? Colors.black
                        : Colors.grey,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _translatedSigns != null && _translatedSigns!.isNotEmpty
                      ? 'Reprodução manual de sinais.'
                      : 'Digite um texto e clique em Traduzir',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.withValues(alpha: 0.6),
                  ),
                ),
                if (_getSpellingProgress() != null) ...[
                  const SizedBox(height: 10),
                  Builder(
                    builder: (context) {
                      final progress = _getSpellingProgress()!;
                      return Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF0F9FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: const Color(0xFFBAE6FD)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Soletrando: ${progress.word.toUpperCase()}',
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF0C4A6E),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              children: progress.letters.asMap().entries.map((entry) {
                                final index = entry.key;
                                final letter = entry.value;
                                final isCurrentLetter = index == progress.currentLetterIndex;
                                return AnimatedContainer(
                                  duration: const Duration(milliseconds: 180),
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: isCurrentLetter
                                        ? const Color(0xFF0284C7)
                                        : Colors.white,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: isCurrentLetter
                                          ? const Color(0xFF0284C7)
                                          : const Color(0xFFBFDBFE),
                                    ),
                                  ),
                                  child: Text(
                                    letter.toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      color: isCurrentLetter
                                          ? Colors.white
                                          : const Color(0xFF0C4A6E),
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ],
                if (_translatedSigns != null && _translatedSigns!.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Status do asset: $_assetStatus',
                    style: TextStyle(
                      fontSize: 11,
                      color: _isCurrentAssetFound ? Colors.green : Colors.orange,
                    ),
                  ),
                  Text(
                    'Status do player: $_playerStatus',
                    style: TextStyle(
                      fontSize: 11,
                      color: _isPlayerReady ? Colors.green : Colors.orange,
                    ),
                  ),
                  if (_currentVideoPath != null)
                    Text(
                      'Arquivo atual: $_currentVideoPath',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 10,
                        color: Colors.grey.withValues(alpha: 0.8),
                      ),
                    ),
                ],
                // Progress bar
                if (_translatedSigns != null && _translatedSigns!.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: (_currentVideoIndex + 1) / _translatedSigns!.length,
                      minHeight: 6,
                      backgroundColor: Colors.grey.withValues(alpha: 0.2),
                      valueColor: AlwaysStoppedAnimation(
                        _isPlayingVideo ? Colors.blue : Colors.green,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Progresso: ${((_currentVideoIndex + 1) / _translatedSigns!.length * 100).toStringAsFixed(0)}%',
                    style: const TextStyle(
                      fontSize: 11,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Lista de sinais traduzidos
          if (_translatedSigns != null && _translatedSigns!.isNotEmpty) ...[
            Text(
              'Sinais Traduzidos',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFFE5E7EB)),
              ),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _translatedSigns!.asMap().entries.map((entry) {
                  final signIndex = entry.key;
                  final sign = entry.value;
                  final isCurrentSign = signIndex == _currentVideoIndex;
                  return InkWell(
                    onTap: () async {
                      setState(() {
                        _currentVideoIndex = signIndex;
                        _isPlayingVideo = false;
                      });
                      _isAutoSequencePlaying = false;
                      await _playCurrentSignVideo(autoPlay: true);
                    },
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: isCurrentSign ? Colors.blue : Colors.grey.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: isCurrentSign ? Colors.blue : const Color(0xFFE5E7EB),
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            sign.word,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: isCurrentSign ? Colors.white : Colors.black,
                            ),
                          ),
                          if (sign.fallbackReason != null) ...[
                            const SizedBox(height: 2),
                            Text(
                              sign.fallbackReason!,
                              style: TextStyle(
                                fontSize: 10,
                                color: isCurrentSign ? Colors.white70 : Colors.grey,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 16),
          ],
          // Botões de controle
          if (_translatedSigns != null && _translatedSigns!.isNotEmpty)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Flexible(
                  child: IconButton(
                    onPressed: _currentVideoIndex > 0 ? _playPreviousSign : null,
                    icon: const Icon(Icons.skip_previous_outlined),
                    tooltip: 'Anterior',
                  ),
                ),
                Flexible(
                  child: IconButton(
                    onPressed: (_isPlayingVideo || !_isPlayerReady || _isSwitchingVideo)
                        ? null
                        : _playSignSequence,
                    icon: const Icon(Icons.play_circle_outlined),
                    tooltip: 'Reproduzir',
                  ),
                ),
                Flexible(
                  child: IconButton(
                    onPressed: _translatedSigns != null &&
                            _currentVideoIndex < _translatedSigns!.length - 1
                        ? _playNextSign
                        : null,
                    icon: const Icon(Icons.skip_next_outlined),
                    tooltip: 'Próximo',
                  ),
                ),
                Flexible(
                  child: IconButton(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Relatório: ${_translatedSigns!.length} sinais traduzidos',
                          ),
                        ),
                      );
                    },
                    icon: const Icon(Icons.info_outlined),
                    tooltip: 'Detalhes',
                  ),
                ),
                Flexible(
                  child: IconButton(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Compartilhado!')),
                      );
                    },
                    icon: const Icon(Icons.share_outlined),
                    tooltip: 'Compartilhar',
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}
